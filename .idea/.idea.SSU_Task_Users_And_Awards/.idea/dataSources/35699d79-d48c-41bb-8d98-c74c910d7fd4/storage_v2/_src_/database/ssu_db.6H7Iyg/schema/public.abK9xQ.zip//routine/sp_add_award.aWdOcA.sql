create procedure sp_add_award(title character varying)
    language sql
as
$$
insert into award(title) values (title);
$$;

alter procedure sp_add_award(varchar) owner to r3v1zor;

