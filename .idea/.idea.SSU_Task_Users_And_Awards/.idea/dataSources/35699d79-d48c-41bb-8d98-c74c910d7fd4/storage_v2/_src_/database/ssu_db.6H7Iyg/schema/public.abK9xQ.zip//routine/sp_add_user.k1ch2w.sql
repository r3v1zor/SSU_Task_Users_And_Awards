create procedure sp_add_user(n character varying, d timestamp without time zone, a integer)
    language sql
as
$$
insert into user_(name, dateOfBirth, age) values (n, d, a)
;
$$;

alter procedure sp_add_user(varchar, timestamp, integer) owner to r3v1zor;

