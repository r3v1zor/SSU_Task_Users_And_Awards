create procedure sp_get_all_users()
    language sql
as
$$
select id, name, dateOfBirth, age from user_;
$$;

alter procedure sp_get_all_users() owner to r3v1zor;

