create procedure sp_delete_award_from_user(userid integer, awardid integer)
    language sql
as
$$
delete from user_to_award uta where uta.userId = userId and uta.awardId = awardId;
$$;

alter procedure sp_delete_award_from_user(integer, integer) owner to r3v1zor;

