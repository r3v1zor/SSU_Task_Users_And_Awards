create procedure sp_add_award_to_user(userid integer, awardid integer)
    language sql
as
$$
insert into user_to_award values (userId, awardId);
$$;

alter procedure sp_add_award_to_user(integer, integer) owner to r3v1zor;

