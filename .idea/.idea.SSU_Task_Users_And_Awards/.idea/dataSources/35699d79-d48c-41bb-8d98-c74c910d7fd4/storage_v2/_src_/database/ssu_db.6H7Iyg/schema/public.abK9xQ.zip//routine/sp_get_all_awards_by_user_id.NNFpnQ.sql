create procedure sp_get_all_awards_by_user_id(id integer)
    language sql
as
$$
select a.id, a.title from user_to_award uta inner join award a on uta.awardId = a.id where uta.userId = id;
$$;

alter procedure sp_get_all_awards_by_user_id(integer) owner to r3v1zor;

