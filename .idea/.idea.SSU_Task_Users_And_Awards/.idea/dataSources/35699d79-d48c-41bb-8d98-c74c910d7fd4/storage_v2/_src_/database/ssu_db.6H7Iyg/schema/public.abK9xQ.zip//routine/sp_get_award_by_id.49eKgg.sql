create procedure sp_get_award_by_id(id integer)
    language sql
as
$$
select id, title from award a where a.id = id;
$$;

alter procedure sp_get_award_by_id(integer) owner to r3v1zor;

