create procedure sp_delete_award(id integer)
    language sql
as
$$
delete from award a where a.id = id;
$$;

alter procedure sp_delete_award(integer) owner to r3v1zor;

