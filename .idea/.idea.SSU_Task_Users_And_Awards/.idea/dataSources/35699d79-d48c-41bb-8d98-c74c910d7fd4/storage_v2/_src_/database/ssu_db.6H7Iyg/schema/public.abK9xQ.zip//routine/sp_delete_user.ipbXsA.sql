create procedure sp_delete_user(id integer)
    language sql
as
$$
delete from user_ u where u.id = id;
$$;

alter procedure sp_delete_user(integer) owner to r3v1zor;

