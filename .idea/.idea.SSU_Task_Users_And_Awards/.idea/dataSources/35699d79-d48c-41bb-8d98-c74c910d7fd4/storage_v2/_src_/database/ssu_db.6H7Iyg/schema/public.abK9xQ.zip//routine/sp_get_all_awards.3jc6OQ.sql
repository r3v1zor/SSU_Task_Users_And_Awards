create procedure sp_get_all_awards()
    language sql
as
$$
select id, title from award;
$$;

alter procedure sp_get_all_awards() owner to r3v1zor;

